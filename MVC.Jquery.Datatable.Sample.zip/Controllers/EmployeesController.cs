﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVC.Jquery.Datatable.Sample.Models;

namespace MVC.Jquery.Datatable.Sample.Controllers
{
    public class EmployeesController : Controller
    {
        private SampleContext db = new SampleContext();

        // GET: Employees
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetData(JqueryDatatableParam param)
        {
            List<Employee> lstEmployee = new List<Employee>();
            IEnumerable<Employee> lstEnEmployee = new List<Employee>();
            
            
            for (int i = 0; i < 200; i++)
            {
                DateTime dateTime = new DateTime();
                dateTime = DateTime.Now.AddDays(-300);
                Employee emp = new Employee();
                emp.Id = i;
                emp.EmpName = i.ToString() + " Employee" ;
                emp.Designation = i.ToString() + " Designation " ;
                emp.Department = i.ToString() + " Department ";
                emp.JoiningDate = dateTime.AddDays(i);
                lstEmployee.Add(emp);
            }

            lstEnEmployee = lstEmployee;
            //lstEnEmployee = db.Employee.ToList();
            var employees = lstEnEmployee;

            //employees.ToList().ForEach(x => x.StartDateString = x.StartDate.ToString("dd'/'MM'/'yyyy"));

            if (!string.IsNullOrEmpty(param.sSearch))
            {
                employees = employees.Where(x => x.EmpName.ToLower().Contains(param.sSearch.ToLower())
                                              || x.Designation.ToLower().Contains(param.sSearch.ToLower())
                                              || x.Department.ToLower().Contains(param.sSearch.ToLower())
                                              || x.JoiningDate.ToString("dd'/'MM'/'yyyy").ToLower().Contains(param.sSearch.ToLower())).ToList();
            }

            var sortColumnIndex = Convert.ToInt32(HttpContext.Request.QueryString["iSortCol_0"]);
            var sortDirection = HttpContext.Request.QueryString["sSortDir_0"];

            if (sortColumnIndex == 3)
            {
                employees = sortDirection == "asc" ? employees.OrderBy(c => c.JoiningDate) : employees.OrderByDescending(c => c.JoiningDate);
            }
            //else if (sortColumnIndex == 2)
            //{
            //    employees = sortDirection == "asc" ? employees.OrderBy(c => c.Designation) : employees.OrderByDescending(c => c.Designation);
            //}
            //else if (sortColumnIndex == 3)
            //{
            //    employees = sortDirection == "asc" ? employees.OrderBy(c => c.Department) : employees.OrderByDescending(c => c.Department);
            //}
            else
            {
                Func<Employee, string> orderingFunction = e => sortColumnIndex == 0 ? e.EmpName :
                                                               sortColumnIndex == 1 ? e.Designation :
                                                               e.Department;

                employees = sortDirection == "asc" ? employees.OrderBy(orderingFunction) : employees.OrderByDescending(orderingFunction);
            }

            var displayResult = employees.Skip(param.iDisplayStart)
                .Take(param.iDisplayLength).ToList();
            var totalRecords = employees.Count();

            return Json(new
            {
                param.sEcho,
                iTotalRecords = totalRecords,
                iTotalDisplayRecords = totalRecords,
                aaData = displayResult
            }, JsonRequestBehavior.AllowGet);

        }

        // GET: Employees/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employee.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        // GET: Employees/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,EmpName,Designation,Department,JoiningDate")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Employee.Add(employee);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee);
        }

        // GET: Employees/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employee.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        // POST: Employees/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,EmpName,Designation,Department,JoiningDate")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        // GET: Employees/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee employee = db.Employee.Find(id);
            if (employee == null)
            {
                return HttpNotFound();
            }
            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee employee = db.Employee.Find(id);
            db.Employee.Remove(employee);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
