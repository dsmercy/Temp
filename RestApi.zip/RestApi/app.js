const express = require('express')
const mongoose = require('mongoose');
const app = express()
const ProductRoute = require('./Routes/Product.routes')

mongoose.connect('mongodb+srv://jaisairam:VdXnHc3O51N1ZJUb@cluster0.eganz.mongodb.net/jaisairam?retryWrites=true&w=majority',{
    useNewUrlParser:true,
    useUnifiedTopology:true
}).then(()=>{
    console.log('MongoDB connected');
});

app.use('/products',ProductRoute);

app.use((req,res,next)=>{
    const error = new Error('Not Found');
    error.status=404;
    next(error);
});

app.use((err,req,res,next)=>{
    res.status(err.status||500);
    res.send({
        error:{
            status:err.status||500,
            message: err.message
        }
    });
});

app.listen(3000,()=>{
    console.log('Server started on 3000');
})