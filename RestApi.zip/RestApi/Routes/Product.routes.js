const express = require('express')
const router = express.Router();


router.get('/',(req,res,next)=>{
    res.send('products List');
})

router.post('/',(req,res,next)=>{
    res.send('product created');
})

router.get('/:id',(req,res,next)=>{
    res.send('product by id accessed');
})

router.patch('/:id',(req,res,next)=>{
    res.send('product Updated');
})
router.delete('/:id',(req,res,next)=>{
    res.send('product deleted');
})

module.exports = router;